# GST ITC Reconciliation Tool

Auto-reconcile GSTR-2B vs Purchase Register. Upload Excel files, get color-coded report.

## Files
- `app.py` — Web UI + server
- `reconcile.py` — Matching engine
- `export.py` — Excel report generator
- `requirements.txt` — Python dependencies

---

## Run Locally

```
pip install -r requirements.txt
python app.py
```
Open browser: http://localhost:5000

---

## Deploy on Render.com (Free, Permanent Link)

1. Create account at https://render.com
2. Create new repo on https://github.com — upload all 5 files
3. On Render: New → Web Service → Connect GitHub repo
4. Settings:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app --bind 0.0.0.0:$PORT`
5. Click Deploy — get your permanent link in 2 minutes

---

## Output Excel Sheets
- **Summary** — ITC counts and amounts
- **Matched ✅** — invoices found on both sides
- **2B Not In Books ❌** — in GSTR-2B but missing from purchase register
- **Books Not In 2B ❌** — booked but supplier hasn't filed
- **Format Mismatch ⚠️** — same invoice, different separator/format
